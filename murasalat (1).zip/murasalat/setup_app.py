# -*- coding: utf-8 -*-
"""
Run ONCE:   python setup_app.py

Creates «متابعة_المراسلات.xlsm» in this folder: one workbook with everything inside —
buttons on «الرئيسية», the «نقل إلى المقفلة» button on «المفتوحة», and all the sheets.
It also marks this folder as a trusted location in Excel so the buttons work without warnings.

Needs: Excel > Options > Trust Center > Macro Settings > «Trust access to the VBA project object model» ticked
(you already did this for the control panel).
"""
import sys
import winreg
from pathlib import Path

HERE = Path(__file__).resolve().parent
APP = HERE / "متابعة_المراسلات.xlsm"
TEMPLATE = HERE / "_buttons_template.xlsm"   # holds only the buttons' code; every rebuild starts from it
PY = sys.executable if sys.executable.isascii() else "python"

THISWORKBOOK = r'''
Private Sub Workbook_SheetFollowHyperlink(ByVal Sh As Object, ByVal Target As Hyperlink)
    If Left(Target.SubAddress, 4) = "ACT_" Then MurasalatApp.RunAction Mid(Target.SubAddress, 5)
End Sub

Private Sub Workbook_Open()
    Dim f As String
    f = ThisWorkbook.Path & "\last_error.txt"
    If CreateObject("Scripting.FileSystemObject").FileExists(f) Then
        MsgBox "The last action did not finish. Details are in run_log.txt in the same folder.", vbExclamation, "Murasalat"
        Kill f
    End If
End Sub
'''

MODULE = r'''
Option Explicit
Private Const PYTHON_EXE As String = "%PY%"

Public Sub RunAction(act As String)
    If act = "send" Then
        If MsgBox("Create today's reminder emails as DRAFTS in Outlook? (nothing will be sent)", vbYesNo + vbQuestion, "Murasalat") <> vbYes Then Exit Sub
    End If
    If act = "move" Then
        If MsgBox("Move the rows that have a send date to the closed sheet?", vbYesNo + vbQuestion, "Murasalat") <> vbYes Then Exit Sub
    End If
    If act = "refresh" Then
        Dim f As Variant
        f = Application.GetOpenFilename("Report (*.xlsx;*.xls;*.csv),*.xlsx;*.xls;*.csv", , "Choose the report file")
        If VarType(f) = vbBoolean Then Exit Sub
        ThisWorkbook.Names("CFG_REPORT").RefersToRange.Value = f
    End If
    ' Your edits are handed over as a copy, so this works even if Excel cannot save the file itself
    Dim copyPath As String
    copyPath = ThisWorkbook.Path & "\~edits.xlsm"
    On Error Resume Next
    Kill copyPath
    Err.Clear
    ThisWorkbook.SaveCopyAs copyPath
    If Err.Number <> 0 Then
        On Error GoTo 0
        MsgBox "Your changes could not be handed over. Close Excel, then run: python setup_app.py", vbExclamation, "Murasalat"
        Exit Sub
    End If
    On Error GoTo 0
    Application.StatusBar = "Murasalat: working... the workbook will reopen by itself"
    Dim cmd As String
    cmd = "cmd /c cd /d """ & ThisWorkbook.Path & """ && """ & PYTHON_EXE & """ murasalat_app.py " & act & " > run_log.txt 2>&1"
    CreateObject("WScript.Shell").Run cmd, 0, False
    Application.StatusBar = False
    Application.DisplayAlerts = False
    ThisWorkbook.Close SaveChanges:=False
End Sub
'''.replace("%PY%", PY)


def trust_folder(version):
    path = rf"Software\Microsoft\Office\{version}\Excel\Security\Trusted Locations\Murasalat"
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, path) as k:
        winreg.SetValueEx(k, "Path", 0, winreg.REG_SZ, str(HERE) + "\\")
        winreg.SetValueEx(k, "AllowSubfolders", 0, winreg.REG_DWORD, 1)
        winreg.SetValueEx(k, "Description", 0, winreg.REG_SZ, "Murasalat follow-up")


def create_workbook(path=None):
    """Create an empty .xlsm with the buttons' code (needs Excel + 'Trust access to the VBA project')."""
    import win32com.client as win32
    xl = win32.DispatchEx("Excel.Application")
    xl.DisplayAlerts = False
    try:
        version = xl.Version
        wb = xl.Workbooks.Add()
        while wb.Worksheets.Count > 1:
            wb.Worksheets(wb.Worksheets.Count).Delete()
        wb.Worksheets(1).Name = "الرئيسية"
        try:
            wb.VBProject.VBComponents("ThisWorkbook").CodeModule.AddFromString(THISWORKBOOK)
            mod = wb.VBProject.VBComponents.Add(1)
            mod.Name = "MurasalatApp"
            mod.CodeModule.AddFromString(MODULE)
        except Exception as e:
            wb.Close(False)
            raise RuntimeError(
                "Excel refused to add the button code. Tick: Excel > File > Options > Trust Center > "
                "Trust Center Settings > Macro Settings > 'Trust access to the VBA project object model', "
                "close Excel, and run again.") from e
        wb.SaveAs(str(path or TEMPLATE), FileFormat=52)   # .xlsm
        wb.Close(False)
    finally:
        xl.Quit()
    try:
        trust_folder(version)
    except Exception as e:
        print("Could not add the trusted location (you may need to click 'Enable Content'):", e)


def main():
    import datetime as dt
    import murasalat_app
    if TEMPLATE.exists():
        TEMPLATE.unlink()
    create_workbook(TEMPLATE)
    if APP.exists():
        backup = APP.with_name(f"backup_{dt.datetime.now():%Y%m%d_%H%M%S}.xlsm")
        APP.rename(backup)
        print(f"Old workbook kept as {backup.name} (your data is safe in murasalat_state.json).")
    print("Buttons added. Building the workbook...")
    murasalat_app.run("track", reopen=True)
    print(f"Done: {APP.name} should open now.")


if __name__ == "__main__":
    main()
