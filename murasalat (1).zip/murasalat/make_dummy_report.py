# -*- coding: utf-8 -*-
"""
Creates a fake system export (same columns and date formats as the real report)
so you can test murasalat.py safely.

    python make_dummy_report.py                 -> reports/dummy_report_<today>.xlsx
    python make_dummy_report.py --today 2026-10-21
    python make_dummy_report.py --today 2026-10-25 --followup
        -> takes the newest dummy report and makes a "later" version of it:
           some transactions closed, some moved to other people, some gone, some new.
"""
import argparse
import datetime as dt
import random
from pathlib import Path

import pandas as pd

BASE = Path(__file__).resolve().parent

PEOPLE = [
    ("سارة العتيبي", "خدمات الموظفين"), ("نورة القحطاني", "خدمات الموظفين"),
    ("محمد الشهري", "الشؤون القانونية"), ("عبدالله الدوسري", "الشؤون القانونية"),
    ("ريم الحربي", "المالية"), ("خالد الغامدي", "المالية"),
    ("هيفاء الزهراني", "المشتريات"), ("فهد المطيري", "تقنية المعلومات"),
    ("لمى السبيعي", "التدريب والتطوير"), ("ياسر العمري", "العلاقات العامة"),
    ("منيرة الشمري", "رأس المال البشري"), ("تركي البقمي", "رأس المال البشري"),
]
SUBJECTS = [
    "طلب تحديث بيانات موظف", "استفسار عن مستحقات نهاية خدمة", "طلب شهادة خبرة",
    "اعتراض على قرار نقل", "طلب تمديد عقد", "مطالبة مالية من جهة خارجية",
    "طلب إفادة عن موظف سابق", "تعميم من جهة حكومية", "طلب معلومات لدراسة",
    "شكوى مراجع", "طلب تعاون تدريبي", "طلب صرف بدل", "استفسار عن إجراءات التوظيف",
]
INTAKE = "الاتصالات الإدارية"


def is_workday(d):
    return d.weekday() not in (4, 5)  # Friday, Saturday


def workdays_back(today, n):
    d = today
    while n > 0:
        d -= dt.timedelta(days=1)
        if is_workday(d):
            n -= 1
    return d


def stamp(day, rnd):
    t = dt.datetime.combine(day, dt.time(rnd.randint(8, 14), rnd.randint(0, 59), rnd.randint(0, 59)))
    return t


def fmt_ts(t):
    return t.strftime("%Y-%m-%d %H:%M:%S") if t else ""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--today", help="YYYY-MM-DD (default: real today)")
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--followup", action="store_true", help="evolve the newest dummy report")
    args = ap.parse_args()
    today = dt.date.fromisoformat(args.today) if args.today else dt.date.today()
    rnd = random.Random(args.seed)
    if args.followup:
        return followup(today, rnd)

    rows = []

    def add(txn, subj, ttype, created, recv, sent, sender, recipient, dept):
        rows.append({
            "المسارات": f"المسار_{len(rows) % 3 + 1} معاملة رقم {txn}",
            "رقم المعاملة": txn, "الموضوع": subj, "نوع المعاملة": ttype,
            "تاريخ الإنشاء": created.strftime("%Y/%m/%d"),
            "تاريخ الإستلام ": fmt_ts(recv), "تاريخ الإرسال": fmt_ts(sent),
            "الإدارات": dept, "المرسل": sender, "المستلم": recipient,
            # the system's own (wrong) duration: calendar days incl. weekends
            "المده": (dt.datetime.combine(today, dt.time()) - recv).days if recv else "",
            "SLA": 0, "درجة الاهمية": rnd.choice(["عادية", "عادية", "عادية", "عاجلة"]),
            "درجة السرية": "عادية", "حالة المعاملة": "active", "متكرر": "",
            "من تاريخ": "1448/04/01", "إلي تاريخ": "1448/04/30", "إسم الإدارة": "رأس المال البشري",
        })

    txn_no = 11400
    # ---- external transactions with different stories ----
    stories = (["simple"] * 10 + ["forward_once"] * 8 + ["forward_twice"] * 4 + ["split"] * 4
               + ["split_partly_closed"] * 2 + ["closed"] * 5 + ["old_open_left"] * 3)
    rnd.shuffle(stories)
    for story in stories:
        txn_no += rnd.randint(1, 6)
        txn = str(txn_no)
        subj = rnd.choice(SUBJECTS)
        age = rnd.randint(1, 14)  # working days since it first arrived
        first_day = workdays_back(today, age)
        created = first_day - dt.timedelta(days=rnd.randint(0, 3))
        a = rnd.choice(PEOPLE)
        t0 = stamp(first_day, rnd)

        if story in ("simple", "closed"):
            sent = None
            if story == "closed":
                sent = stamp(workdays_back(today, rnd.randint(0, max(0, age - 1))), rnd)
                if sent <= t0:
                    sent = t0 + dt.timedelta(hours=3)
            add(txn, subj, "خارجية", created, t0, sent, INTAKE, a[0], a[1])
            continue

        hops = {"forward_once": 1, "forward_twice": 2, "split": 1,
                "split_partly_closed": 1, "old_open_left": 1}[story]
        cur, t = a, t0
        hop_gap = max(1, age // (hops + 1))
        for h in range(hops):
            nxt_day = workdays_back(today, max(0, age - hop_gap * (h + 1)))
            nt = stamp(nxt_day, rnd)
            if nt <= t:
                nt = t + dt.timedelta(hours=2)
            # old_open_left: the forwarder never closed their own row
            sent = None if story == "old_open_left" else nt
            add(txn, subj, "خارجية", created, t, sent, INTAKE if h == 0 else prev[0], cur[0], cur[1])
            prev, cur, t = cur, rnd.choice([p for p in PEOPLE if p != cur]), nt

        if story.startswith("split"):
            group = [cur] + rnd.sample([p for p in PEOPLE if p not in (cur, prev)], rnd.randint(1, 2))
            for i, p in enumerate(group):
                sent = None
                if story == "split_partly_closed" and i == 0:
                    sent = t + dt.timedelta(hours=5)
                add(txn, subj, "خارجية", created, t, sent, prev[0], p[0], p[1])
        else:
            add(txn, subj, "خارجية", created, t, None, prev[0], cur[0], cur[1])

    # ---- noise that must be ignored ----
    for _ in range(14):
        txn_no += rnd.randint(1, 4)
        p = rnd.choice(PEOPLE)
        d = workdays_back(today, rnd.randint(1, 12))
        add(str(txn_no), rnd.choice(SUBJECTS), rnd.choice(["داخلية", "داخلية", ""]),
            d, stamp(d, rnd), None, INTAKE, p[0], p[1])

    rnd.shuffle(rows)
    out_dir = BASE / "reports"
    out_dir.mkdir(exist_ok=True)
    out = out_dir / f"dummy_report_{today.isoformat()}.xlsx"
    pd.DataFrame(rows).to_excel(out, index=False)
    print(f"Dummy report written: {out}  ({len(rows)} rows)")


def followup(today, rnd):
    files = sorted((BASE / "reports").glob("dummy_report_*.xlsx"), key=lambda p: p.stat().st_mtime)
    if not files:
        raise SystemExit("Make a first report before --followup")
    df = pd.read_excel(files[-1], dtype=str).fillna("")
    rows = df.to_dict("records")
    ext = [r for r in rows if r["نوع المعاملة"] == "خارجية"]
    by = {}
    for r in ext:
        by.setdefault(r["رقم المعاملة"], []).append(r)
    drop = set()
    for txn, rs in by.items():
        last = max(r["تاريخ الإستلام "] for r in rs)
        holders = [r for r in rs if r["تاريخ الإستلام "] == last and not r["تاريخ الإرسال"]]
        if not holders:
            continue
        roll = rnd.random()
        when = stamp(workdays_back(today, rnd.randint(0, 2)), rnd)
        if roll < 0.35:                                   # everyone closed
            for h in holders:
                h["تاريخ الإرسال"] = fmt_ts(when)
        elif roll < 0.45 and len(holders) > 1:            # one of several closed
            holders[0]["تاريخ الإرسال"] = fmt_ts(when)
        elif roll < 0.60:                                 # passed on to someone else
            h = holders[0]
            h["تاريخ الإرسال"] = fmt_ts(when)
            p = rnd.choice([x for x in PEOPLE if x[0] != h["المستلم"]])
            new = dict(h)
            new.update({"تاريخ الإستلام ": fmt_ts(when), "تاريخ الإرسال": "", "المرسل": h["المستلم"],
                        "المستلم": p[0], "الإدارات": p[1]})
            rows.append(new)
        elif roll < 0.68:                                 # vanished from the report
            drop.add(txn)
    rows = [r for r in rows if r["رقم المعاملة"] not in drop]
    start = max(int(r["رقم المعاملة"]) for r in rows) + 1
    for i in range(4):                                    # brand-new transactions
        p = rnd.choice(PEOPLE)
        d = workdays_back(today, rnd.randint(0, 2))
        t = stamp(d, rnd)
        rows.append({**rows[0], "المسارات": f"المسار_1 معاملة رقم {start + i}", "رقم المعاملة": str(start + i),
                     "الموضوع": rnd.choice(SUBJECTS), "نوع المعاملة": "خارجية", "تاريخ الإنشاء": d.strftime("%Y/%m/%d"),
                     "تاريخ الإستلام ": fmt_ts(t), "تاريخ الإرسال": "", "المرسل": INTAKE, "المستلم": p[0], "الإدارات": p[1]})
    out = BASE / "reports" / f"dummy_report_{today.isoformat()}.xlsx"
    pd.DataFrame(rows).to_excel(out, index=False)
    print(f"Follow-up dummy report written: {out}  (closed/moved/dropped/new mixed in)")


if __name__ == "__main__":
    main()
