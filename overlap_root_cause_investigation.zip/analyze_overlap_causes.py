# -*- coding: utf-8 -*-
"""Sensitivity audit for Q4 2026 leave overlaps. No causal conclusion without HR policy/rosters."""
from collections import defaultdict, Counter
from itertools import combinations
from pathlib import Path
import pandas as pd
import ports_audit_presentation_ready as base

START, END = pd.Timestamp("2026-10-01"), pd.Timestamp("2026-12-31")
OUTPUT = "تحليل اسباب ارتفاع نسبة تزامن الاجازات.xlsx"
# Change only after confirming the actual definition with HRIS.
# Inclusive: Actual End Date is last leave day.
# Exclusive: Actual End Date is first day NOT on leave.
DAY_RULES = ("inclusive", "exclusive")

def valid_log():
    raw, cols = base.load()
    df = base.build_log(raw, cols)
    df = df[(df["حالة التدقيق"] == "داخل التدقيق")
            & df["الرقم الوظيفي"].ne("")
            & df["المدير"].ne("") & df["المنفذ"].ne("")].copy()
    df["تاريخ البداية"] = pd.to_datetime(df["تاريخ البداية"], errors="coerce").dt.normalize()
    df["تاريخ النهاية"] = pd.to_datetime(df["تاريخ النهاية"], errors="coerce").dt.normalize()
    df = df.dropna(subset=["تاريخ البداية", "تاريخ النهاية"])
    df = df[df["تاريخ النهاية"] >= df["تاريخ البداية"]].copy()
    df = df[(df["تاريخ البداية"] <= END) & (df["تاريخ النهاية"] >= START)].copy()
    df = df.reset_index(drop=True)
    df["record_id"] = df.index + 1
    return df

def build_calendar(df, rule):
    days = defaultdict(set)
    rec_days = defaultdict(set)
    for r in df.itertuples(index=False):
        manager, location, person = r[df.columns.get_loc("المدير")], r[df.columns.get_loc("المنفذ")], r[df.columns.get_loc("الرقم الوظيفي")]
        a, b = r[df.columns.get_loc("تاريخ البداية")], r[df.columns.get_loc("تاريخ النهاية")]
        last = b if rule == "inclusive" else b - pd.Timedelta(days=1)
        a, last = max(a, START), min(last, END)
        if a > last: continue
        for day in pd.date_range(a, last):
            days[(manager, location, day)].add(person)
            rec_days[(int(r[df.columns.get_loc("record_id")]), day)].add(person)
    return days, rec_days

def evaluate(days, min_people=2, min_days=1, working=False):
    person_days = defaultdict(set)
    group_day = []
    for (mgr, loc, day), persons in days.items():
        # Saudi office assumption only; ports may have shifts.
        if working and day.weekday() not in (6,0,1,2,3): continue
        if len(persons) < min_people: continue
        group_day.append((mgr, loc, day, len(persons)))
        for pid in persons: person_days[pid].add(day)
    affected = {pid for pid, dates in person_days.items() if len(dates) >= min_days}
    return affected, person_days, group_day

def analyze():
    df = valid_log()
    if df.empty: raise ValueError("No eligible leave records for Q4 2026.")
    denominator = df["الرقم الوظيفي"].nunique()
    cal, rec_cal = build_calendar(df, "inclusive")
    excl, rec_excl = build_calendar(df, "exclusive")
    inc, inc_days, inc_daily = evaluate(cal)
    exc, exc_days, exc_daily = evaluate(excl)
    # Alternative half-open rule may drop single-day leave entirely; not automatically valid.
    invalid_exclusive = int((df["تاريخ البداية"] == df["تاريخ النهاية"]).sum())
    duplicates = df.duplicated(["الرقم الوظيفي","المدير","المنفذ","تاريخ البداية","تاريخ النهاية"],keep=False)
    distinct_assign = df.groupby("الرقم الوظيفي").apply(
        lambda g: len(set(zip(g["المدير"],g["المنفذ"]))),include_groups=False)
    affected_only_boundary = inc - exc
    person_rows = []
    names = df.drop_duplicates("الرقم الوظيفي").set_index("الرقم الوظيفي")["اسم الموظف"].to_dict()
    for pid in sorted(df["الرقم الوظيفي"].unique()):
        a, b = inc_days.get(pid,set()), exc_days.get(pid,set())
        person_rows.append({"الرقم الوظيفي":pid,"اسم الموظف":names.get(pid,""),
            "ايام تزامن مع شمول النهاية":len(a),
            "ايام تزامن مع استبعاد النهاية":len(b),
            "متاثر بالاحتساب الحالي":int(bool(a)),
            "متاثر بعد استبعاد النهاية":int(bool(b)),
            "فقد التصنيف عند استبعاد النهاية":int(pid in affected_only_boundary),
            "ايام تزامن حدودية تزول":len(a-b)})
    persons = pd.DataFrame(person_rows)
    scenarios=[]
    for label, days in [("شمول تاريخ النهاية",cal),("استبعاد تاريخ النهاية (افتراضي)",excl)]:
        for working in (False,True):
            for min_people in (2,3,5,10):
                for min_days in (1,2,3,5):
                    affected, _, groupdays = evaluate(days,min_people,min_days,working)
                    scenarios.append({"قاعدة النهاية":label,
                        "نوع الايام":"الاحد-الخميس (افتراض)" if working else "تقويمية",
                        "الحد الادنى للمتزامنين":min_people,
                        "الحد الادنى لايام التزامن للموظف (غير مشروطة بالتتابع)":min_days,
                        "الموظفون المتأثرون":len(affected),
                        "النسبة من اصحاب الاجازات":len(affected)/denominator,
                        "ايام المدير-المنفذ":len(groupdays)})
    scenarios = pd.DataFrame(scenarios)
    # Identify meeting boundary pairs, distinguish those with ONLY shared boundary day.
    meeting=[]
    for (mgr,loc),g in df.groupby(["المدير","المنفذ"]):
        records=list(g[["record_id","الرقم الوظيفي","تاريخ البداية","تاريخ النهاية"]].itertuples(index=False,name=None))
        for a,b in combinations(records,2):
            if a[1]==b[1]: continue
            overlap_start=max(a[2],b[2],START)
            overlap_end=min(a[3],b[3],END)
            if overlap_start>overlap_end: continue
            boundary=(a[3]==b[2] or b[3]==a[2])
            if not boundary: continue
            meeting.append({"المدير":mgr,"المنفذ":loc,"سجل 1":a[0],"سجل 2":b[0],
                "الموظف 1":a[1],"الموظف 2":b[1],"تاريخ الالتقاء":overlap_start,
                "ايام التداخل":(overlap_end-overlap_start).days+1,
                "تداخل يوم واحد فقط":int(overlap_start==overlap_end)})
    meeting=pd.DataFrame(meeting,columns=["المدير","المنفذ","سجل 1","سجل 2","الموظف 1","الموظف 2","تاريخ الالتقاء","ايام التداخل","تداخل يوم واحد فقط"])
    # Distinct leave records participating in overlap (not just distinct employees).
    overlapping_records = set()
    for (record_id,day),_ in rec_cal.items():
        row = df.iloc[record_id-1]
        if len(cal[(row["المدير"],row["المنفذ"],day)])>=2:
            overlapping_records.add(record_id)
    records = df[["record_id","الرقم الوظيفي","اسم الموظف","المدير","المنفذ","تاريخ البداية","تاريخ النهاية"]].copy()
    records["سجل اجازة متزامنة"] = records["record_id"].isin(overlapping_records).astype(int)
    distribution=[]
    for lo,hi,label in [(2,4,"2-4"),(5,9,"5-9"),(10,15,"10-15"),(16,999999,"16+")]:
        count=sum(lo<=n<=hi for _,_,_,n in inc_daily)
        distribution.append({"عدد المتزامنين":label,"ايام المدير-المنفذ":count,
                             "نسبة من ايام التزامن":count/len(inc_daily) if inc_daily else 0})
    distribution=pd.DataFrame(distribution)
    month=defaultdict(lambda:{"days":set(),"affected":set()})
    for mgr,loc,day,n in inc_daily:
        key=day.strftime("%Y-%m")
        month[key]["days"].add((mgr,loc,day))
        month[key]["affected"].update(cal[(mgr,loc,day)])
    months=pd.DataFrame([{"الشهر":m,"ايام المدير-المنفذ":len(v["days"]),
                          "الموظفون المتأثرون في الشهر":len(v["affected"])}
                         for m,v in sorted(month.items())])
    group_sizes = df.groupby(["المدير","المنفذ"])["الرقم الوظيفي"].nunique().to_dict()
    groups=defaultdict(lambda:{"days":0,"peak":0,"people":set()})
    for mgr,loc,day,n in inc_daily:
        d=groups[(mgr,loc)]
        d["days"]+=1;d["peak"]=max(d["peak"],n);d["people"].update(cal[(mgr,loc,day)])
    group_df=pd.DataFrame([{"المدير":m,"المنفذ":l,
        "اصحاب اجازات فريدون بالمجموعة (ليس اجمالي القوى العاملة)":group_sizes.get((m,l),0),
        "الموظفون المتأثرون":len(v["people"]),"ايام التزامن":v["days"],"اقصى تزامن":v["peak"]}
        for (m,l),v in groups.items()])
    if not group_df.empty: group_df=group_df.sort_values("الموظفون المتأثرون",ascending=False)
    overview=pd.DataFrame([
        ("اصحاب الاجازات الفريدون في المصدر",denominator,"مقام النسبة، وليس اجمالي الموظفين 6193"),
        ("المتأثرون مع شمول تاريخ النهاية",len(inc),"يوم مشترك واحد يكفي"),
        ("النسبة الحالية المعاد احتسابها",len(inc)/denominator,"قارنها مع 89.8%؛ اختلافها يعني اختلاف نطاق/منهجية"),
        ("المتأثرون عند استبعاد تاريخ النهاية",len(exc),"سيناريو افتراضي، ليس تصحيحا معتمدا"),
        ("النسبة عند استبعاد تاريخ النهاية",len(exc)/denominator,"لا تعتمد الا بعد التحقق من تعريف الحقل"),
        ("موظفون زال تصنيفهم فقط بسبب قاعدة النهاية",len(affected_only_boundary),"عدد موظفين فريدين، وليس عدد حالات"),
        ("الفرق بالنقاط المئوية",(len(inc)-len(exc))/denominator,"اثر قاعدة النهاية على النسبة"),
        ("اجازات يوم واحد ستختفي اذا استبعدت النهاية",invalid_exclusive,"تحذير: علامة قوية على عدم صلاحية الاستبعاد الشامل"),
        ("سجلات اجازات فيها تزامن",len(overlapping_records),"السجل الواحد يحسب مرة"),
        ("اجمالي سجلات الاجازات",len(df),"قبل حذف السجلات المكررة"),
        ("سجلات ضمن مجموعات تكرار مطابقة",int(duplicates.sum()),"مراجعة جودة بيانات؛ التزامن اليومي يستخدم موظفين فريدين"),
        ("موظفون بعدة مديرين او منافذ",int((distinct_assign>1).sum()),"قد يكون انتقالا او اختلاف بيانات"),
        ("ازواج اجازات تلتقي عند حد البداية والنهاية",len(meeting),"قد تشمل اكثر من زوج في اليوم نفسه"),
        ("ازواج تداخلها يوم واحد فقط عند الحدود",int(meeting["تداخل يوم واحد فقط"].sum()),"عدد ازواج، وليس موظفين"),
        ("عدد ايام المدير والمنفذ ذات التزامن",len(inc_daily),"لا يساوي عدد الايام التقويمية الفريدة"),
    ],columns=["المؤشر","القيمة","التفسير"])
    warnings=pd.DataFrame([
        ("تعريف Actual End Date","لا يمكن اثباته من ملف الاجازات وحده؛ راجعي HRIS او سجل العودة"),
        ("الاستبعاد التلقائي","اذا كان تاريخ النهاية آخر يوم اجازة فاستبعاده يخفي غيابا حقيقيا"),
        ("اجازات اليوم الواحد","قاعدة النهاية الحصرية تحذفها تماما؛ لا تعتمدي هذا السيناريو دون تفسير رسمي"),
        ("اسباب ارتفاع النسبة","الاختبارات تقيس تأثير الافتراضات ولا تثبت سببا جذريا وحيدا"),
        ("تداخل الاجازات","لا يثبت عجزا تشغيليا بدون جداول الورديات والحد الادنى للتغطية"),
        ("الايام الاحد-الخميس","افتراض غير موثوق لعمال المنافذ ذوي الورديات"),
        ("تكرار السجلات","اكتشاف التكرار لا يثبت ان السجلات خاطئة"),
        ("تفسير المقام","المقام هنا اصحاب الاجازات من المصدر وليس حصر الموظفين 6193"),
        ("نطاق المدير والمنفذ","التزامن يحسب داخل المدير والمنفذ نفسيهما في بيانات الاجازات"),
        ("تعريف المدة","حد ادنى لايام التزامن للموظف عبر الربع؛ ليس بالضرورة اياما متصلة"),
    ],columns=["التحقق المطلوب","السبب"])
    tables=[("ملخص الادلة",overview),("اختبار جميع الفرضيات",scenarios),("اثر تاريخ النهاية",persons),
            ("الالتقاء عند الحدود",meeting),("سجلات الاجازات",records),
            ("شدة التزامن",distribution),("حسب الشهر",months),("حسب المنفذ",group_df),("قيود الاستنتاج",warnings)]
    with pd.ExcelWriter(OUTPUT,engine="openpyxl",datetime_format="dd/mm/yyyy") as writer:
        from openpyxl.styles import Font,PatternFill,Alignment
        for name,table in tables:
            table.to_excel(writer,sheet_name=name,index=False)
            ws=writer.sheets[name];ws.sheet_view.rightToLeft=True;ws.freeze_panes="B2"
            ws.auto_filter.ref=ws.dimensions
            for cell in ws[1]:
                cell.fill=PatternFill("solid",fgColor="17365D")
                cell.font=Font(name="Arial",bold=True,color="FFFFFF")
            for col in ws.columns:
                letter=col[0].column_letter
                ws.column_dimensions[letter].width=min(70,max(18,max(len(str(c.value or "")) for c in list(col)[:90])+3))
            if name=="ملخص الادلة":
                for row in (4,6,8): ws.cell(row,2).number_format="0.0%"
            if name=="اختبار جميع الفرضيات":
                for c in ws["F"][1:]: c.number_format="0.0%"
            if name=="شدة التزامن":
                for c in ws["C"][1:]: c.number_format="0.0%"
    print("Created:",OUTPUT)
    print("Inclusive:",len(inc),f"{len(inc)/denominator:.1%}")
    print("Exclusive:",len(exc),f"{len(exc)/denominator:.1%}")
    print("Boundary-sensitive unique employees:",len(affected_only_boundary))
    print("WARNING: Excluding end date drops",invalid_exclusive,"single-day leave records.")
    print("These are sensitivity tests, NOT proof that the end date should be excluded.")

if __name__=="__main__":
    analyze()
