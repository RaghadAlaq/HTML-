"""Synthetic contract tests; these do not verify a user's real report."""
import tempfile, unittest, json, re, subprocess
from pathlib import Path
from openpyxl import Workbook, load_workbook
import backend as b

class Checks(unittest.TestCase):
 def test_week_boundaries(self):
  c=[dict(id='1',start='2026-11-19',end='2026-11-24')]
  weeks=b.weekly_rows(c,'2026-10-01','2026-12-31')
  self.assertEqual(len(weeks),14)
  self.assertEqual(weeks[0]['end'],'2026-10-03')
  self.assertEqual(weeks[-1]['start'],'2026-12-27')
  self.assertEqual(sum(w['count'] for w in weeks),2)
  self.assertEqual(sum((__import__('datetime').date.fromisoformat(w['end'])-__import__('datetime').date.fromisoformat(w['start'])).days+1 for w in weeks),92)
 def test_report_comparison(self):
  with tempfile.TemporaryDirectory() as d:
   a=Path(d)/'a.xlsx';z=Path(d)/'z.xlsx';w=Workbook();w.remove(w.active)
   for name in b.REPORT_SHEETS:
    s=w.create_sheet(name)
    for row in [['title'],['dept'],['date'],['اسم','نسبة'],['س',50],['س',50]]:s.append(row)
   w.save(a);w.save(z);self.assertEqual(b.compare_reports(a,z),[])
   w[b.REPORT_SHEETS[0]].cell(5,2,60);w.save(z);self.assertTrue(b.compare_reports(a,z))
   w[b.REPORT_SHEETS[0]].cell(5,2,50);w[b.REPORT_SHEETS[0]].delete_rows(6);w.save(z);self.assertTrue(b.compare_reports(a,z))
 def test_browser_logic(self):
  group=dict(id='g',manager='مدير تجريبي',port='منفذ تجريبي',type='بري',workforce=6,latitude='',longitude='')
  case=dict(id='1',group_id='g',start='2026-11-19',end='2026-11-24',days=6,people=3,percent=50,remaining=3,status='قادمة',action='',employee_ids='1,2,3')
  leaves=[dict(id=str(i),employee_id=str(i),group_id='g',name='موظف تجريبي '+str(i),start='2026-11-19',end='2026-11-24') for i in range(1,4)]
  leaves.append(dict(id='4',employee_id='4',group_id='g',name='موظف غير متقاطع',start='2026-12-25',end='2026-12-31'))
  data=dict(groups=[group],cases=[case],employees=[dict(id=str(i),name='موظف '+str(i)) for i in range(1,5)],leaves=leaves,weeks=b.weekly_rows([case],'2026-10-01','2026-12-31'),meta=dict(as_of='2026-11-12',presentation_date='2026-11-18',verified=0))
  js=Path(b.ROOT/'frontend.html').read_text().split('<script>')[-1].split('</script>')[0]
  pre='const assert=require("node:assert/strict"); const elements=new Map(); const fixture='+json.dumps(data,ensure_ascii=False)+';\n'+'''global.document={getElementById(id){if(!elements.has(id))elements.set(id,{value:'',innerHTML:'',hidden:false,style:{},textContent:id==='report-data'?JSON.stringify(fixture):'',querySelectorAll(){return []},showModal(){},close(){}});return elements.get(id)},querySelectorAll(){return []},addEventListener(){}};\n'''
  post='''
const chart=elements.get('weeklychart').innerHTML;
assert(chart.includes('الأسبوع 1'));
query='غير مطابق';render();assert.equal(elements.get('weeklychart').innerHTML,chart);
query='';solve();
assert.equal(current.find(x=>x.id==='4').s,base.find(x=>x.id==='4').s);
for(const l of current){assert.equal(l.e-l.s,base.find(x=>x.id===l.id).e-base.find(x=>x.id===l.id).s);if(l.s!==base.find(x=>x.id===l.id).s)assert(!current.some(x=>blocks(l,x)));}
assert.deepEqual(DATA.cases,fixture.cases);
assert(weeklyDetails(DATA.weeks.find(w=>w.count)).includes('6 أيام متصلة'));
assert(weeklyDetails(DATA.weeks.find(w=>w.count)).includes('(50%)'));
const g=G.get('g');query='';const one=base[0];assert.equal(intersects(one,{...one,id:'other'}),false);
console.log('JS checks passed');
'''
  with tempfile.TemporaryDirectory() as d:
   f=Path(d)/'check.js';f.write_text(pre+js+post);subprocess.run(['node',str(f)],check=True,capture_output=True)

if __name__=='__main__':unittest.main()
