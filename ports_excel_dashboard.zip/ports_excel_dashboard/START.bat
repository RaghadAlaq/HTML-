@echo off
chcp 65001 >nul
cd /d "%~dp0"
python backend.py --config config.json
if errorlevel 1 (
  pause
  exit /b 1
)
start "" "output\dashboard.html"
pause
