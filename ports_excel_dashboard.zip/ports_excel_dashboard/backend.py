# -*- coding: utf-8 -*-
"""Run the user's approved report unchanged, capture its already-computed results,
append dashboard data to a COPY, and compare all four report sheets to baseline.
No independent overlap calculation is used for dashboard report figures.
"""
import argparse, hashlib, importlib.util, json, math, os, re, shutil, sys, tempfile
from collections import Counter
from datetime import date, datetime, timedelta
from pathlib import Path
import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment

ROOT=Path(__file__).resolve().parent
REPORT_SHEETS=['حالات 50 فأكثر','ملخص المدير والمنفذ','تطابق كامل 50 فأكثر','ضبط الجودة']
DATA_SHEETS={'groups':'بيانات المجموعات','cases':'بيانات الحالات','leaves':'بيانات الإجازات','employees':'بيانات الموظفين','mapping_issues':'ملاحظات الربط','weeks':'بيانات الأسابيع'}
HEADERS={
 'weeks':['week','start','end','count','case_ids'],
 'groups':['id','manager_id','manager','title','port','port_code','type','region','level1','level2','level3','level_detail','workforce','latitude','longitude'],
 'cases':['id','group_id','start','end','days','people','percent','remaining','status','action','employee_ids'],
 'leaves':['id','group_id','employee_id','name','start','end'],
 'employees':['id','group_id','name'],
 'mapping_issues':['port_source','issue']}

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def iso(x):return x.isoformat() if isinstance(x,(date,datetime)) else str(x)
def clean(x):
 if x is None:return ''
 if isinstance(x,float) and math.isnan(x):return ''
 if isinstance(x,float) and x.is_integer():return int(x)
 if isinstance(x,(date,datetime)):return x.strftime('%d/%m/%Y')
 return x

def report_tables(path):
 wb=load_workbook(path,read_only=True,data_only=True)
 try:
  out={}
  for title in REPORT_SHEETS:
   if title not in wb.sheetnames:raise ValueError('ورقة التقرير المطلوبة غير موجودة: '+title)
   rows=list(wb[title].values)
   # This approved script inserts exactly 3 report-heading rows.
   if len(rows)<4:raise ValueError('رؤوس التقرير غير موجودة في الصف الرابع: '+title)
   headers=tuple(clean(v) for v in rows[3]);data=[tuple(clean(v) for v in r) for r in rows[4:] if any(v is not None for v in r)]
   out[title]=(headers,data)
  return out
 finally:wb.close()

def compare_reports(generated,baseline):
 a,b=report_tables(generated),report_tables(baseline);diff=[]
 for title in REPORT_SHEETS:
  ah,ar=a[title];bh,br=b[title]
  if ah!=bh:diff.append({'sheet':title,'issue':'اختلاف رؤوس الأعمدة','generated':list(ah),'reference':list(bh)});continue
  # Order is presentation only; compare full row multiset, preserving duplicates.
  key=lambda row:json.dumps(row,ensure_ascii=False,default=str,separators=(',',':'))
  ac,bc=Counter(map(key,ar)),Counter(map(key,br))
  for kind,delta in [('غير موجود في المرجع',ac-bc),('مفقود من الناتج',bc-ac)]:
   for row,n in delta.items():diff.append({'sheet':title,'issue':kind,'count':n,'row':json.loads(row)})
 return diff

def baseline_date(path):
 qa=dict(report_tables(path)['ضبط الجودة'][1]);v=qa.get('تاريخ تصنيف الحالات')
 if not v:raise ValueError('تاريخ تصنيف الحالات غير موجود في ضبط الجودة في التقرير المرجعي.')
 try:return date.fromisoformat(str(v)).isoformat()
 except ValueError:return datetime.strptime(str(v),'%d/%m/%Y').date().isoformat()

def run_approved(config,out,asof):
 source=Path(config['approved_script']).resolve()
 if not source.is_file():raise FileNotFoundError('احفظي السكربت المعتمد الذي أرسلته باسم approved_report.py أو حددي مساره في config.json.')
 spec=importlib.util.spec_from_file_location('approved_ports_report',source);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 required=['build','norm','empid','col','cell','excel_read']
 if any(not hasattr(mod,k) for k in required):raise ValueError('السكربت لا يطابق واجهة السكربت المعتمد المرسل.')
 mod.MANAGERS_FILE=str(Path(config['managers_file']).resolve());mod.LEAVES_FILE=str(Path(config['leaves_file']).resolve());mod.OUTPUT_FILE=str(out);mod.AS_OF=asof
 # Do not override approval handling, grouping, thresholds, dates, inclusive-end,
 # translations, parsing, exclusions or any other approved algorithm setting.
 captured={};previous=sys.getprofile()
 def capture(frame,event,arg):
  if event=='return' and frame.f_code is mod.build.__code__:captured.update(frame.f_locals)
 try:
  sys.setprofile(capture);mod.build()
 finally:sys.setprofile(previous)
 need={'priority','cases','group_staff','staff','staff_by_id','record_signatures','managers_by_id','display_port','common'}
 if not need.issubset(captured):raise ValueError('تعذر استخراج نتائج السكربت المعتمد؛ لم يتم إنشاء بيانات بديلة.')
 if float(mod.THRESHOLD)!=50:raise ValueError('هذه الواجهة مخصصة للنسخة المعتمدة بحد 50%.')
 return mod,captured

def arabic(value,fallback='غير متاح'):
 text=str(value or '').strip()
 return text if text and not re.search('[A-Za-z]',text) else fallback

def mapping_index(path,mod):
 if not path:return {}
 df=mod.excel_read(path,'Sheet1');idx={}
 for _,r in df.iterrows():
  entry={str(k).strip():clean(v) for k,v in r.items()}
  for k in ['Location (Name)','Name']:
   if entry.get(k):
    key=mod.norm(entry[k]);bucket=idx.setdefault(key,[])
    if entry not in bucket:bucket.append(entry)
 return idx

def extract(mod,c,config):
 data={k:[] for k in DATA_SHEETS};index=mapping_index(config.get('mapping_file'),mod);group_ids={};names={}
 for _,r in c['staff'].iterrows():
  eid=mod.empid(mod.cell(r,c['si']));name=mod.cell(r,c['sn'])
  if eid in c['staff_by_id'] and name:names.setdefault(eid,set()).add(name)
 def name_of(eid):
  vs=names.get(eid,set());return arabic(next(iter(vs))) if len(vs)==1 else ('اسم غير محسوم' if len(vs)>1 else 'اسم غير متاح')
 for g,staff in sorted(c['group_staff'].items()):
  gid=hashlib.sha256(json.dumps(g,ensure_ascii=False).encode()).hexdigest()[:20];group_ids[g]=gid
  common=c['common'](g);source_port=c['display_port'][g];matches=index.get(mod.norm(source_port),[]);m=matches[0] if len(matches)==1 else {}
  # Only explicit Arabic fields are used as translations. No fuzzy matching.
  title=arabic(common[1]);port=arabic(m.get('أسم الموقع عربي') or m.get('اسم الموقع عربي') or source_port,'اسم المنفذ غير مترجم')
  category=str(m.get('Category (Picklist Label)','')).strip().casefold();typ={'land port':'بري','air port':'جوي','airport':'جوي','sea port':'بحري','seaport':'بحري','بري':'بري','جوي':'جوي','بحري':'بحري'}.get(category,'غير محدد')
  region=arabic(m.get('المنطقه الإدارية') or m.get('المنطقة الإدارية'))
  # Extra optional approved translation columns, because original Mapping headers
  # do not contain Arabic manager job titles or Arabic organizational levels.
  title=arabic(m.get('المسمى الوظيفي للمدير عربي') or title)
  levels=[arabic(m.get(f'المستوى {n} عربي') or common[i+3]) for i,n in enumerate(['الأول','الثاني','الثالث'])]
  def coordinate(key,limit):
   try:
    n=float(m.get(key,''));return n if math.isfinite(n) and -limit<=n<=limit else ''
   except (TypeError,ValueError):return ''
  data['groups'].append(dict(zip(HEADERS['groups'],[gid,g[0],arabic(common[0]),title,port,str(m.get('Code','')),typ,region,*levels,arabic(common[6]),len(staff),coordinate('العرض2',90),coordinate('الطول2',180)])))
  if len(matches)!=1:data['mapping_issues'].append({'port_source':source_port,'issue':'لا توجد مطابقة مرجعية' if not matches else 'مطابقة مرجعية متعددة؛ لم تستخدم'})
  for eid in sorted(staff):data['employees'].append({'id':eid,'group_id':gid,'name':name_of(eid)})
 for n,case in enumerate(c['priority'],1):
  data['cases'].append({'id':str(n),'group_id':group_ids[case['group']],'start':iso(case['start']),'end':iso(case['end']),'days':case['days'],'people':case['people'],'percent':round(case['percent'],1),'remaining':case['remaining'],'status':case['status'],'action':c['short_action'](case),'employee_ids':case['employees']})
 for n,(eid,g,st,en) in enumerate(sorted(c['record_signatures'],key=lambda x:(x[1],x[0],x[2],x[3])),1):
  data['leaves'].append({'id':str(n),'group_id':group_ids[g],'employee_id':eid,'name':name_of(eid),'start':iso(st),'end':iso(en)})
 data['weeks']=weekly_rows(data['cases'],mod.PERIOD_START,mod.PERIOD_END)
 if len(data['cases'])!=len(c['priority_rows']):raise ValueError('فشل تطابق عدد الحالات مع التقرير.')
 for row,case in zip(c['priority_rows'],data['cases']):
  if (case['people'],case['percent'],case['days'])!=(row[9],row[10],row[13]):raise ValueError('فشل تطابق قيم الحالة مع التقرير.')
 return data

def weekly_rows(cases,start,end):
 """Sunday–Saturday, clipped to quarter; distinct approved cases active each week."""
 first=date.fromisoformat(start);last=date.fromisoformat(end);out=[];cursor=first
 while cursor<=last:
  stop=min(last,cursor+timedelta(days=(5-cursor.weekday())%7))
  members=[str(c['id']) for c in cases if c['start']<=stop.isoformat() and c['end']>=cursor.isoformat()]
  out.append(dict(week=len(out)+1,start=cursor.isoformat(),end=stop.isoformat(),count=len(members),case_ids=','.join(members)))
  cursor=stop+timedelta(days=1)
 return out


def set_text(cell,value):
 cell.value=value
 if isinstance(value,str):cell.data_type='s' # Avoid formulas from names or source text.

def append_data(report,destination,data,metadata):
 shutil.copy2(report,destination);wb=load_workbook(destination)
 for key,title in DATA_SHEETS.items():
  ws=wb.create_sheet(title);ws.append(HEADERS[key])
  for obj in data[key]:
   row=ws.max_row+1
   for j,h in enumerate(HEADERS[key],1):set_text(ws.cell(row,j),obj.get(h,''))
  ws.freeze_panes='A2';ws.sheet_view.rightToLeft=True;ws.auto_filter.ref=ws.dimensions
  for cell in ws[1]:cell.fill=PatternFill('solid',fgColor='152446');cell.font=Font(name='Arial',color='FFFFFF',bold=True)
  for column in ws.columns:ws.column_dimensions[column[0].column_letter].width=24
 ws=wb.create_sheet('إعدادات العرض');ws.append(['key','value'])
 for k,v in metadata.items():ws.append([k,v])
 wb.save(destination)

def read_dashboard(path):
 wb=load_workbook(path,read_only=True,data_only=True)
 try:
  meta={r[0]:r[1] for r in list(wb['إعدادات العرض'].values)[1:]};data={}
  for key,title in DATA_SHEETS.items():
   rows=iter(wb[title].values);headers=next(rows)
   data[key]=[{h:clean(v) for h,v in zip(headers,row)} for row in rows if any(v is not None for v in row)]
  # IDs always remain text, including numeric-looking identifiers.
  for key in ['groups','cases','leaves','employees']:
   for row in data[key]:
    for field in ['id','group_id','employee_id','employee_ids','manager_id','port_code']:
     if field in row:row[field]=str(row[field])
  data['meta']=meta;return data
 finally:wb.close()

def workbook_fingerprint(path):
 data=read_dashboard(path)
 data['meta'].pop('content_sha256',None)
 payload={'data':data,'report':report_tables(path)}
 return hashlib.sha256(json.dumps(payload,ensure_ascii=False,sort_keys=True,default=str,separators=(',',':')).encode()).hexdigest()

def seal_workbook(path):
 signature=workbook_fingerprint(path)
 wb=load_workbook(path);wb['إعدادات العرض'].append(['content_sha256',signature]);wb.save(path)


def render_dashboard(workbook,output):
 data=read_dashboard(workbook)
 if data['meta'].get('content_sha256')!=workbook_fingerprint(workbook):raise ValueError('تغير محتوى ملف العرض أو لم يتم التحقق منه. أعيدي تشغيل backend.py من المصادر والمرجع.')
 payload=json.dumps(data,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
 template=(ROOT/'frontend.html').read_text(encoding='utf-8')
 if template.count('__REPORT_JSON__')!=1:raise ValueError('قالب الواجهة غير صالح.')
 Path(output).write_text(template.replace('__REPORT_JSON__',payload),encoding='utf-8')

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--config',default=str(ROOT/'config.json'));parser.add_argument('--render',help='إعادة بناء HTML من ملف Excel الناتج فقط');parser.add_argument('--unverified',action='store_true',help='تشغيل تجريبي دون تقرير مرجعي؛ لا يؤكد التطابق')
 args=parser.parse_args()
 if args.render:
  p=Path(args.render).resolve();render_dashboard(p,p.with_suffix('.html'));print(p.with_suffix('.html'));return
 cfg_path=Path(args.config).resolve();cfg=json.loads(cfg_path.read_text(encoding='utf-8-sig'))
 for key in ['approved_script','managers_file','leaves_file','mapping_file','reference_report','output_dir']:
  if cfg.get(key):cfg[key]=str((cfg_path.parent/Path(cfg[key])).resolve())
 ref=cfg.get('reference_report');verified=bool(ref and Path(ref).is_file())
 if not verified and not args.unverified:raise FileNotFoundError('أضيفي التقرير المرسل للإدارات في reference_report. لم يُشغّل التحليل ولم تتغير المخرجات.')
 asof=baseline_date(ref) if verified else (cfg.get('as_of') or date.today().isoformat())
 output=Path(cfg.get('output_dir') or ROOT/'output');output.mkdir(parents=True,exist_ok=True)
 # Build in a temporary directory; publish files only after all checks pass.
 with tempfile.TemporaryDirectory(dir=output) as temp:
  report=Path(temp)/'approved_report.xlsx';mod,c=run_approved(cfg,report,asof)
  diff=compare_reports(report,ref) if verified else []
  audit={'verified':verified and not diff,'as_of':asof,'reference_sha256':digest(ref) if verified else '', 'script_sha256':digest(cfg['approved_script']),'differences':diff}
  (output/'comparison.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
  if diff:raise ValueError('توجد اختلافات عن التقرير المرسل. توقّف إنشاء الداشبورد. راجعي comparison.json؛ المخرجات السابقة لم تتغير.')
  data=extract(mod,c,cfg);meta={'as_of':asof,'presentation_date':cfg.get('presentation_date','2026-11-18'),'period_start':mod.PERIOD_START,'period_end':mod.PERIOD_END,'threshold':mod.THRESHOLD,'verified':int(verified),'script_sha256':audit['script_sha256'],'reference_sha256':audit['reference_sha256'],'managers_sha256':digest(cfg['managers_file']),'leaves_sha256':digest(cfg['leaves_file']),'built_at':datetime.now().isoformat(timespec='seconds')}
  xlsx=Path(temp)/'dashboard.xlsx';append_data(report,xlsx,data,meta)
  # Verify appended workbook still contains exact original report tables.
  if compare_reports(xlsx,report):raise ValueError('تغيرت جداول التقرير أثناء إعداد ملف العرض.')
  seal_workbook(xlsx)
  html=Path(temp)/'dashboard.html';render_dashboard(xlsx,html)
  for src in [xlsx,html]:os.replace(src,output/src.name)
 print('تم إنشاء dashboard.xlsx وdashboard.html في: '+str(output))
 print('التقرير مطابق للمرجع.' if verified else 'نسخة غير متحقق من مطابقتها: لم يقدم تقرير مرجعي.')

if __name__=='__main__':
 try:main()
 except Exception as exc:print('خطأ: '+str(exc),file=sys.stderr);sys.exit(1)
